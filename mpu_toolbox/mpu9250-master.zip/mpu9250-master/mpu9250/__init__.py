__version__ = '0.0.1'

from mpu9250 import mpu9250
