#!/usr/bin/env python


def test_dummy():
	assert True
